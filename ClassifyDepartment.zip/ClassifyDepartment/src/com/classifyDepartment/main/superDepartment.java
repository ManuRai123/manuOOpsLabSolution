package com.classifyDepartment.main;

class SuperDepartment{
	String S1;

	String departmentName (){
		S1=String.valueOf("Super Department");
		return S1;
	}

	String getTodaysWork  () {
		S1=String.valueOf("No Work as of now");
		return S1;
	}

	String getWorkDeadline() {
		S1=String.valueOf("Nil");
		return S1;
	}

	String isTodayAHoliday() {
		S1=String.valueOf("Today is not a holiday");
		return S1;
	}
}

class adminDepartment extends SuperDepartment {
	String departmentName (){
		S1=String.valueOf("Admin Department");
		return S1;
	}
	String getTodaysWork  () {
		S1=String.valueOf("Complete your documents Submission");
		return S1;
	}
	String getWorkDeadline() {
		S1=String.valueOf("Complete by EOD ");
		return S1;
	}
}

class hrDepartment extends SuperDepartment {
	String departmentName (){
		S1=String.valueOf("Hr Department");
		return S1;
	}
	String getTodaysWork  () {
		S1=String.valueOf("Fill today's worksheet and mark your attendance");
		return S1;
	}
	String getWorkDeadline() {
		S1=String.valueOf("Complete by EOD");
		return S1;
	}
	String doActivity() {
		S1=String.valueOf("team Lunch");
		return S1;
	}
}

class techDepartment extends SuperDepartment {
	String departmentName (){
		S1=String.valueOf("Tech Department");
		return S1;
	}
	String getTodaysWork  () {
		S1=String.valueOf("Complete coding of module 1");
		return S1;
	}
	String getWorkDeadline() {
		S1=String.valueOf("Complete by EOD");
		return S1;
	}
	String getTechStackInformation() {
		S1=String.valueOf("core Java");
		return S1;
	}
}
