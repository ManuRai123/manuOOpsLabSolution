package com.classifyDepartment.main;


public class Driver {

	public static void main(String[] args) {
		adminDepartment obj1 = new adminDepartment();
		hrDepartment obj2 = new hrDepartment();
		techDepartment obj3 = new techDepartment();
		
		System.out.println("Welcome to "+obj1.departmentName());
		System.out.println(obj1.getTodaysWork());
		System.out.println(obj1.getWorkDeadline());
		System.out.println(obj1.isTodayAHoliday());
		System.out.println();
		
		System.out.println("Welcome to "+obj2.departmentName());
		System.out.println(obj2.doActivity());
		System.out.println(obj2.getTodaysWork());
		System.out.println(obj2.getWorkDeadline());
		System.out.println(obj2.isTodayAHoliday());
		System.out.println();
		
		System.out.println("Welcome to "+obj3.departmentName());
		System.out.println(obj3.getTodaysWork());
		System.out.println(obj3.getWorkDeadline());
		System.out.println(obj3.getTechStackInformation());
		System.out.println(obj3.isTodayAHoliday());
	}
}
